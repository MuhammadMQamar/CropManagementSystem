package ca.sunshineboys.it.cropmanagementsystem;

import androidx.lifecycle.ViewModel;
/*
Sivajan Manikavasagar (Team Leader) N01240148
Muhammad Qamar N01344609
Noha Philips N01351336
Tanvir Pahwa N01245843
CENG 322 - RNC/D
CENG 317 - 0NF
 */
public class WaterLevelViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}