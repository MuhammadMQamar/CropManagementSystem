# Crop Management System

The Crop Management System project by The Sunshine Boys brings the convenience of everyday farming to the 21st century. The system is designed to automatically care for crops 
and makes it easier to monitor the health of plants on your phone. 
## Sivajan Manikavasagar n01240148
Team leader in charge of delegation, app development, and planning.  

## Muhammad Qamar n01344609
Sensor calibration and data analysis.
## Noha Philips n01351336
Documentation and Product design.
## Tanvir Pahwa n01245843

Hardware selection, testing, and engineering.


### Sunshine Boys
